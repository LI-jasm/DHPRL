import argparse
import sys


argv = sys.argv
dataset = argv[1]


def dip_params():
    parser = argparse.ArgumentParser()
    parser.add_argument('--save_emb', action="store_true", default=True)
    parser.add_argument('--turn', type=int, default=0)
    parser.add_argument('--dataset', type=str, default="dip")
    parser.add_argument('--ratio', type=int, default=[20, 40, 60])
    parser.add_argument('--cpu', type=int, default=0)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--hidden_dim', type=int, default=128)# 64
    parser.add_argument('--nb_epochs', type=int, default=10000)

    parser.add_argument('--drop_rate', type=float, help='drop rate', default=0.01)
    parser.add_argument('--num_gradual', type=int, default=50, help='how many epochs to linearly increase drop_rate')
    parser.add_argument('--exponent', type=float, default=1, help='exponent of the drop rate {0.5, 1, 2}')

    # The parameters of evaluation
    parser.add_argument('--eva_lr', type=float, default=0.01)
    parser.add_argument('--eva_wd', type=float, default=0)

    # The parameters of learning process
    parser.add_argument('--patience', type=int, default=10)# 20
    parser.add_argument('--lr', type=float, default=0.0008)
    parser.add_argument('--l2_coef', type=float, default=0)

    # model-specific parameters
    parser.add_argument('--tau', type=float, default=0.5)
    parser.add_argument('--feat_drop', type=float, default=0.1)
    parser.add_argument('--attn_drop', type=float, default=0.3)
    parser.add_argument('--sample_rate', nargs='+', type=int, default=[5,3,2])# 532
    parser.add_argument('--lam', type=float, default=0.5)# 0.5

    args, _ = parser.parse_known_args()
    args.type_num = [4928, 100, 42]  # the number of every node type
    args.nei_num = 3  # the number of neighbors' types
    return args

def biogrid_params():
    parser = argparse.ArgumentParser()
    parser.add_argument('--save_emb', action="store_true", default=True)
    parser.add_argument('--turn', type=int, default=0)
    parser.add_argument('--dataset', type=str, default="biogrid")
    parser.add_argument('--ratio', type=int, default=[20, 40, 60])
    parser.add_argument('--cpu', type=int, default=0)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--hidden_dim', type=int, default=128)
    parser.add_argument('--nb_epochs', type=int, default=10000)

    parser.add_argument('--drop_rate', type=float, help='drop rate', default=0.01)
    parser.add_argument('--num_gradual', type=int, default=50, help='how many epochs to linearly increase drop_rate')
    parser.add_argument('--exponent', type=float, default=1, help='exponent of the drop rate {0.5, 1, 2}')

    # The parameters of evaluation
    parser.add_argument('--eva_lr', type=float, default=0.001)
    parser.add_argument('--eva_wd', type=float, default=0)

    # The parameters of learning process
    parser.add_argument('--patience', type=int, default=20)
    parser.add_argument('--lr', type=float, default=0.0001)
    parser.add_argument('--l2_coef', type=float, default=0)

    # model-specific parameters
    parser.add_argument('--tau', type=float, default=0.5)
    parser.add_argument('--feat_drop', type=float, default=0.1)
    parser.add_argument('--attn_drop', type=float, default=0.3)
    parser.add_argument('--sample_rate', nargs='+', type=int, default=[5,3,2])# 532
    parser.add_argument('--lam', type=float, default=0.5)# 0.5

    args, _ = parser.parse_known_args()
    args.type_num = [5640, 100, 42]  # the number of every node type
    args.nei_num = 3  # the number of neighbors' types
    return args

def collins_params():
    parser = argparse.ArgumentParser()
    parser.add_argument('--save_emb', action="store_true", default=True)
    parser.add_argument('--turn', type=int, default=0)
    parser.add_argument('--dataset', type=str, default="collins")
    parser.add_argument('--ratio', type=int, default=[20, 40, 60])
    parser.add_argument('--cpu', type=int, default=0)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--hidden_dim', type=int, default=128)# 64
    parser.add_argument('--nb_epochs', type=int, default=10000)

    parser.add_argument('--drop_rate', type=float, help='drop rate', default=0.01)
    parser.add_argument('--num_gradual', type=int, default=50, help='how many epochs to linearly increase drop_rate')
    parser.add_argument('--exponent', type=float, default=1, help='exponent of the drop rate {0.5, 1, 2}')

    # The parameters of evaluation
    parser.add_argument('--eva_lr', type=float, default=0.003)
    parser.add_argument('--eva_wd', type=float, default=0)

    # The parameters of learning process
    parser.add_argument('--patience', type=int, default=25)
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--l2_coef', type=float, default=0)

    # model-specific parameters
    parser.add_argument('--tau', type=float, default=0.5)
    parser.add_argument('--feat_drop', type=float, default=0.1)
    parser.add_argument('--attn_drop', type=float, default=0.3)
    parser.add_argument('--sample_rate', nargs='+', type=int, default=[5,3,2])# 532
    parser.add_argument('--lam', type=float, default=0.5)# 0.5

    args, _ = parser.parse_known_args()
    args.type_num = [1622, 100, 42]  # the number of every node type
    args.nei_num = 3  # the number of neighbors' types
    return args

def krogan14k_params():
    parser = argparse.ArgumentParser()
    parser.add_argument('--save_emb', action="store_true", default=True)
    parser.add_argument('--turn', type=int, default=0)
    parser.add_argument('--dataset', type=str, default="krogan14k")
    parser.add_argument('--ratio', type=int, default=[20, 40, 60])
    parser.add_argument('--cpu', type=int, default=0)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--hidden_dim', type=int, default=128)# 64
    parser.add_argument('--nb_epochs', type=int, default=10000)

    parser.add_argument('--drop_rate', type=float, help='drop rate', default=0.01)
    parser.add_argument('--num_gradual', type=int, default=50, help='how many epochs to linearly increase drop_rate')
    parser.add_argument('--exponent', type=float, default=1, help='exponent of the drop rate {0.5, 1, 2}')

    # The parameters of evaluation
    parser.add_argument('--eva_lr', type=float, default=0.01)
    parser.add_argument('--eva_wd', type=float, default=0)

    # The parameters of learning process
    parser.add_argument('--patience', type=int, default=50)
    parser.add_argument('--lr', type=float, default=0.003)
    parser.add_argument('--l2_coef', type=float, default=0)

    # model-specific parameters
    parser.add_argument('--tau', type=float, default=0.5)
    parser.add_argument('--feat_drop', type=float, default=0.1)
    parser.add_argument('--attn_drop', type=float, default=0.3)
    parser.add_argument('--sample_rate', nargs='+', type=int, default=[5,3,2])# 532
    parser.add_argument('--lam', type=float, default=0.5)# 0.5

    args, _ = parser.parse_known_args()
    args.type_num = [3581, 100, 42]  # the number of every node type
    args.nei_num = 3  # the number of neighbors' types
    return args

def krogan2006core_params():
    parser = argparse.ArgumentParser()
    parser.add_argument('--save_emb', action="store_true", default=True)
    parser.add_argument('--turn', type=int, default=0)
    parser.add_argument('--dataset', type=str, default="krogan2006core")
    parser.add_argument('--ratio', type=int, default=[20, 40, 60])
    parser.add_argument('--cpu', type=int, default=0)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--hidden_dim', type=int, default=128)# 64
    parser.add_argument('--nb_epochs', type=int, default=10000)

    parser.add_argument('--drop_rate', type=float, help='drop rate', default=0.01)
    parser.add_argument('--num_gradual', type=int, default=50, help='how many epochs to linearly increase drop_rate')
    parser.add_argument('--exponent', type=float, default=1, help='exponent of the drop rate {0.5, 1, 2}')

    # The parameters of evaluation
    parser.add_argument('--eva_lr', type=float, default=0.01)# 0.01
    parser.add_argument('--eva_wd', type=float, default=0)

    # The parameters of learning process
    parser.add_argument('--patience', type=int, default=20)# 20
    parser.add_argument('--lr', type=float, default=0.0001)# 0.001
    parser.add_argument('--l2_coef', type=float, default=0)

    # model-specific parameters
    parser.add_argument('--tau', type=float, default=0.5)
    parser.add_argument('--feat_drop', type=float, default=0.1)
    parser.add_argument('--attn_drop', type=float, default=0.3)
    parser.add_argument('--sample_rate', nargs='+', type=int, default=[5,3,2])# 532
    parser.add_argument('--lam', type=float, default=0.5)# 0.5

    args, _ = parser.parse_known_args()
    args.type_num = [2708, 100, 42]  # the number of every node type
    args.nei_num = 3  # the number of neighbors' types
    return args

def set_params():
    if dataset == "dip":
        args = dip_params()
    elif dataset == "biogrid":
        args = biogrid_params()
    elif dataset == "collins":
        args = collins_params()
    elif dataset == "krogan14k":
        args = krogan14k_params()
    elif dataset == "krogan2006core":
        args = krogan2006core_params()
    return args
