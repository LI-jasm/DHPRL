import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from .mp_encoder import Mp_encoder
from .sc_encoder import Sc_encoder
from .contrast import Contrast

def drop_rate_schedule(epoch, drop_rate, exponent, num_gradual):
    droprate = np.linspace(0, drop_rate ** exponent, num_gradual)  # 0到0.04中间的100个数（droprate）
    if epoch < num_gradual:
        return droprate[epoch]
    else:
        return drop_rate  # 100轮之后droprate不变，都为0.04

def cal_pairwise_ce_loss_with_Truncated(node_emb, edge, drop_rate):
    # pos loss
    emb_u_i = node_emb[edge['r']]
    emb_u_j = node_emb[edge['c']]
    inner_product = torch.sum(emb_u_i * emb_u_j, dim=1)
    pos_loss = - F.logsigmoid(inner_product)

    ind_sorted = np.argsort(pos_loss.cpu().data).cpu()  # 从小到大的索引
    loss_sorted = pos_loss[ind_sorted]  # 从小到大的损失值
    remember_rate = 1 - drop_rate
    num_remember = int(remember_rate * len(loss_sorted))
    ind_update = ind_sorted[:num_remember]
    pos_loss_update = torch.mean(pos_loss[ind_update])

    return pos_loss_update


class HeCo(nn.Module):
    def __init__(self, hidden_dim, feats_dim_list, feat_drop, attn_drop, P, sample_rate,
                 nei_num, tau, lam):
        super(HeCo, self).__init__()
        self.hidden_dim = hidden_dim
        self.fc_list = nn.ModuleList([nn.Linear(feats_dim, hidden_dim, bias=True)
                                      for feats_dim in feats_dim_list])
        for fc in self.fc_list:
            nn.init.xavier_normal_(fc.weight, gain=1.414)

        if feat_drop > 0:
            self.feat_drop = nn.Dropout(feat_drop)
        else:
            self.feat_drop = lambda x: x
        self.mp = Mp_encoder(P, hidden_dim, attn_drop)
        self.sc = Sc_encoder(hidden_dim, sample_rate, nei_num, attn_drop)      
        self.contrast = Contrast(hidden_dim, tau, lam)

    def forward(self, epoch, edge, feats, pos, mps, nei_index, drop_rate, exponent, num_gradual):  # p a s
        h_all = []
        for i in range(len(feats)):
            h_all.append(F.elu(self.feat_drop(self.fc_list[i](feats[i]))))
        z_mp = self.mp(h_all[0], mps)
        z_sc = self.sc(h_all, nei_index)
        pairwise_loss = cal_pairwise_ce_loss_with_Truncated(z_sc, edge, drop_rate_schedule(epoch, drop_rate, exponent, num_gradual))
        contrast_loss = self.contrast(z_mp, z_sc, pos)
        # loss = pairwise_loss + contrast_loss
        loss = contrast_loss
        return loss

    def get_embeds(self, feats, mps):
        z_mp = F.elu(self.fc_list[0](feats[0]))
        z_mp = self.mp(z_mp, mps)
        return z_mp.detach()
